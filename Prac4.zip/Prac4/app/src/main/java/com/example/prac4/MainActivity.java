package com.example.prac4;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    ListView list;
    String tp[]={"Bangalore","Mangalore","Coorg","Shimoga","Mysore",};
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        list=(ListView)findViewById(R.id.listview);
        ArrayAdapter<String> ob= new ArrayAdapter<>(this,R.layout.activity_listview, R.id.textView, tp);
        list.setAdapter(ob);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                String s=(String)parent.getItemAtPosition(position);
                Toast.makeText(getBaseContext(),"You have selected " + s,Toast.LENGTH_LONG).show();
            }
        });
    }
}