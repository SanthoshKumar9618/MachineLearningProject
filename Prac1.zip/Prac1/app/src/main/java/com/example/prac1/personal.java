package com.example.prac1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
public class personal extends AppCompatActivity
{
    Button b;
    Intent main;
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal);
        b=(Button)findViewById(R.id.bahome);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
               main=new Intent(getBaseContext(), MainActivity.class);
               startActivity(main);
            }
        });
    }
}
