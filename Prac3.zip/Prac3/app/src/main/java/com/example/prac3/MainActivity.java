package com.example.prac3;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
   private GestureDetectorCompat mGestureDetector;
   private class GestureListener extends GestureDetector.SimpleOnGestureListener
   {
       public boolean onSingleTapConfirmed(MotionEvent e)
       {
           Toast.makeText(MainActivity.this,"Single Tap Received",Toast.LENGTH_SHORT).show();
           setContentView(R.layout.layoutone);
           return super.onSingleTapConfirmed(e);
       }
       public boolean onDoubleTap(MotionEvent e)
       {
           Toast.makeText(MainActivity.this,"Double Tap Received",Toast.LENGTH_SHORT).show();
           setContentView(R.layout.layouttwo);
           return super.onDoubleTap(e);
       }
   }
    public boolean onTouchEvent(MotionEvent event)
    {
       mGestureDetector.onTouchEvent(event);
       return super.onTouchEvent(event);
    }
    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        mGestureDetector=new GestureDetectorCompat(this,new GestureListener());
    }
}

