package com.example.prac7;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;

public class MainActivity extends AppCompatActivity
{
    @Override
   public void onCreate(Bundle savedInstanceState)
   {
       super.onCreate(savedInstanceState);
       setContentView(new myView(this));
   }
   private static class myView extends View
   {
       Paint myPaint;
       public myView(Context context)
       {
          super(context);
          init();
       }
       private void init()
       {
           myPaint=new Paint();
           myPaint.setColor(Color.BLUE);
           myPaint.setStyle(Paint.Style.FILL_AND_STROKE);
           myPaint.setStrokeWidth(7);

       }
       @Override
       protected void onDraw(Canvas canva)
       {
           super.onDraw(canva);
           canva.drawRect(200,400,650,450,myPaint);
           canva.drawCircle(200,350,150,myPaint);
           canva.drawRect(50, 750, 200, 950, myPaint);
           canva.drawLine(520,850,520,950,myPaint);
       }
   }
}