package com.example.prac6;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    Button ba,bs,bm,bd;
    EditText n1,n2;
    TextView result;
    double val1,val2,r;
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ba=(Button)findViewById(R.id.add);
        bs=(Button)findViewById(R.id.sub);
        bm=(Button)findViewById(R.id.mul);
        bd=(Button)findViewById(R.id.div);
        n1=(EditText)findViewById(R.id.e1);
        n2=(EditText)findViewById(R.id.e2);
        result=(TextView)findViewById(R.id.res);

        ba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
               val1=Double.parseDouble(n1.getText().toString());
               val2=Double.parseDouble(n2.getText().toString());
               r=val1+val2;
               result.setText(Double.toString(r));
            }
        });

        bs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                val1=Double.parseDouble(n1.getText().toString());
                val2=Double.parseDouble(n2.getText().toString());
                r=val1-val2;
                result.setText(Double.toString(r));
            }
        });

        bm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                val1=Double.parseDouble(n1.getText().toString());
                val2=Double.parseDouble(n2.getText().toString());
                r=val1*val2;
                result.setText(Double.toString(r));
            }
        });

        bd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                val1=Double.parseDouble(n1.getText().toString());
                val2=Double.parseDouble(n2.getText().toString());
                r=val1/val2;
                result.setText(Double.toString(r));
            }
        });
    }
}
