package com.example.prac8;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class MainActivity extends Activity implements OnClickListener
{
    EditText usn,name,marks;
    Button insert,delete,update,View,Viewall;
    SQLiteDatabase db;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        usn = (EditText) findViewById(R.id.usn);
        name = (EditText) findViewById(R.id.name);
        marks = (EditText) findViewById(R.id.mark);
        insert = (Button) findViewById(R.id.save);
        delete = (Button) findViewById(R.id.delete);
        update = (Button) findViewById(R.id.update);
        View = (Button) findViewById(R.id.view);
        Viewall = (Button) findViewById(R.id.viewall);
        insert.setOnClickListener(this);
        delete.setOnClickListener(this);
        update.setOnClickListener(this);
        View.setOnClickListener(this);
        Viewall.setOnClickListener(this);
        db = openOrCreateDatabase("StudentDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS student(USN INT PRIMARY KEY, Name VARCHAR,Marks VARCHAR);");
    }
    public void onClick(View view)
    {
       if(view==insert)
       {
           if(usn.getText().toString().trim().length()==0||
              name.getText().toString().trim().length()==0||
              marks.getText().toString().trim().length()==0)
           {
               showMessage("Error","Enter all details.");
               return;
           }
           db.execSQL("insert into student values('"+usn.getText()+"','"+name.getText()+"','"+marks.getText()+"'");
           showMessage("Success","Record Added");
           clearText();
       }

       if(view==delete) {
           if (usn.getText().toString().trim().length() == 0) {
               showMessage("Error", "Enter the Roll Number");
               return;
           }
           Cursor c = db.rawQuery("select * from student where USN='" + usn.getText() + "'", null);
           if (c.moveToFirst()) {
               db.execSQL("delete from student where USN='" + usn.getText() + "'");
               showMessage("Success", "Record Deleted");
           } else {
               showMessage("Error", "Invalid USN");
           }
           clearText();
       }

        if(view==update) {
            if (usn.getText().toString().trim().length() == 0) {
                showMessage("Error", "Enter the Roll Number");
                return;
            }
            Cursor c = db.rawQuery("select * from student where USN='" + usn.getText() + "'", null);
            if (c.moveToFirst()) {
                db.execSQL("update student set USN='" + usn.getText() + "',Name='"+name.getText()+"',Marks='"+marks.getText()+"'");
                showMessage("Success", "Record Updated");
            } else {
                showMessage("Error", "Invalid USN");
            }
            clearText();
        }

        if(view==View) {
            if (usn.getText().toString().trim().length() == 0) {
                showMessage("Error", "Enter the Roll Number");
                return;
            }
            Cursor c = db.rawQuery("select * from student where USN='" + usn.getText() + "'", null);
            if (c.moveToFirst()) {
                name.setText(c.getString(1));
                marks.setText(c.getString(2));
            } else {
                showMessage("Error", "Invalid USN");
                clearText();
            }


        }

        if(view==Viewall)
        {
           Cursor c=db.rawQuery("select * from student",null);
           if(c.getCount()==0)
           {
               showMessage("Error", "No records found");
               return;
           }
           StringBuffer buffer=new StringBuffer();
           while(c.moveToFirst())
           {
               buffer.append("USN: "+c.getString(0)+"\n");
               buffer.append("Name: "+c.getString(1)+"\n");
               buffer.append("Marks: "+c.getString(2)+"\n");
           }
           showMessage("Student Details: ", buffer.toString());
        }

    }
public void showMessage(String title,String message)
{
  Builder builder=new Builder(this);
  builder.setCancelable(true);
  builder.setTitle(title);
  builder.setMessage(message);
  builder.show();
}
public void clearText()
{
  usn.setText("");
  name.setText("");
  marks.setText("");
  usn.requestFocus();
}

}