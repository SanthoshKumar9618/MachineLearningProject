package com.example.prac9;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.media.MediaPlayer;

public class MainActivity extends AppCompatActivity {
    MediaPlayer mp;
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mp =MediaPlayer.create(getBaseContext(),R.raw.iphone);
    }

    public void mplay(View view)
    {
        mp.start();
    }
    public void mpause(View view)
    {
        mp.pause();
    }
    public void mstop(View view)
    {
        mp.stop();
        mp =MediaPlayer.create(getBaseContext(),R.raw.iphone);

    }
}