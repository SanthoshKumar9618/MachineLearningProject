package com.example.prac9;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;

public class splashactivity extends AppCompatActivity
{
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        Thread t = new Thread(new Runnable()
        {
            @Override
            public void run() {
                try
                {
                    Thread.sleep(5000);

                }
                catch(InterruptedException e)
                {
                    e.printStackTrace();
                }
                finally
                {
                    Intent i=new Intent(splashactivity.this,MainActivity.class);
                    startActivity(i);
                }

            }
        });
        t.start();
    }
}
